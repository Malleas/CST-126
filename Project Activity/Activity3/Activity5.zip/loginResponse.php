<head>
    <title></title>
<body>
<h2>Login was successful<?php echo " " . $userName; ?></h2>
<a href="whoAmI.php">Who Am I</a>
</body>
</head>


