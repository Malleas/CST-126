<?php
$id = $_GET['id'];
$mode = $_GET['mode'];

echo "The ID is ".$id."<br />";
echo "And the mode is ".$mode;
