<head>
    <title></title>
    <body>
    <h2><?php echo $message?></h2>
    </body>
</head>
